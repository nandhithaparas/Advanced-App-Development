import React from 'react'
import './Menu.css'

export default function Menubar() {
  return (
    <div><div className='icon-border'>
    <div className='icon-border-closure'>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-flower-v202306.png'/>
    <div className='icon-text'>Flowers</div>
    </div>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-SDD-v202306.png'/>
    <div className='icon-text'>Fast Delivery</div>
    </div>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-cakes-v202306.png'/>
    <div className='icon-text'>Cakes</div>
    </div>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-personalize-v202306.png'/>
    <div className='icon-text'>Custom</div>
    </div>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-plants-v202306.png'/>
    <div className='icon-text'>Plants</div>
    </div>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-sweets-v202306.png'/>
    <div className='icon-text'>Gourmet</div>
    </div>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-bulk-order-v202306.png'/>
    <div className='icon-text'>Bulk Gifts</div>
    </div>
    <div className='icon-border1'>
    <img src='https://cdn.igp.com/f_auto,q_auto,t_pnopt0prodlp/banners/w-tiles-flower-v202306.png'/>
    <div className='icon-text'>Flowers</div>
    </div>
    </div>
    </div></div>
  )
}
